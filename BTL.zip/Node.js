class Node {
    constructor(student) {
        this.student = student;
        this.next = null;
    }
}

module.exports = Node;
